package com.fixitytech.Ekart;

import java.util.List;
import java.util.Vector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class AddCartController {
	@Autowired
	ItemDAO itemDAO;
	@RequestMapping(value="/addCart" ,method=RequestMethod.GET)
	 String index( HttpSession hs,Model m,@RequestParam("id") String itemId)
	 {
		//HttpSession hs = request.getSession();
		List<CartItem> cart = (List) hs.getAttribute("cart");
		if (cart == null)
			cart = new Vector<CartItem>();

		//String itemId = request.getParameter("id");
		boolean isAdded = false;
		for (CartItem cItem : cart) 
		{
			if (cItem.getId() == Integer.parseInt(itemId)) 
			{
				cItem.setQuantity(cItem.getQuantity() + 1);
				isAdded = true;
				break;
			}
		}
		if (!isAdded) 
		{
			Item item = ItemDAO.getItem(itemId);
			if (item != null) 
			{
				CartItem citem = new CartItem();
				citem.setId(item.getId());
				citem.setName(item.getName());
				citem.setPrice(item.getPrice());
				citem.setQuantity(1);
				
				// cart = new Vector<Item>();
				cart.add(citem);
//				String path=getServletContext().getRealPath("")+"/uploads/";
//					File file=new File(path+item.getId());
//					if(file.exists()) {
//						
//						
//					String names[]=file.list();
//					if(names.length>0) {
//					String name=names[0];
//					
//					citem.setBase64Image("uploads/"+item.getId()+"/"+name);
//					}
//					}
//				

			}
		}
		hs.setAttribute("cart", cart);

		return "redirect:index";
	 }}
