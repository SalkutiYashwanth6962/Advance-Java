package com.fixitytech.Ekart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Ekart2Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext conf= SpringApplication.run(Ekart2Application.class, args);
		
		Index index=conf.getBean(Index.class);
		index.show();
	}

}
