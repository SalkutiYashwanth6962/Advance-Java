package com.fixitytech.Ekart;

import java.io.File;
import java.util.List;
import java.util.Vector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class IndexController {

	 void show()
	{
		System.out.println("hello");
	}
	 @Autowired
	 ItemDAO itemDAO;
	 
	 @RequestMapping(value="/index" ,method=RequestMethod.GET)
	 String index( HttpSession hs,Model m)
	 {
		
			List<CartItem> cart =(List)hs.getAttribute("cart");
			
			if(cart==null) 
				cart = new Vector<CartItem>();
			hs.setAttribute("cart", cart);  
			List<Item> products = itemDAO.getItems();

			//String path=getServletContext().getRealPath("")+"/uploads/";
//			for(Item item:products)
//			{
//				File file=new File(path+item.getId());
//				String names[]=file.list();
//				String name=names[0];
//				item.setBase64Image("uploads/"+item.getId()+"/"+name);
//			}
			
			m.addAttribute("prs", products);//forwarding to view page
//	        
//			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
//			rd.forward(request, response);
		     return "index";
	 }
	 @RequestMapping(value="/index" ,method=RequestMethod.POST)
	 String index1()
	 {
		 //index(null, null);
		return "index";
	 }
}
