package com.fixitytech.Ekart;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Index {

	 void show()
	{
		System.out.println("hello");
	}
	 
	 @RequestMapping("/home")
	 String goHome()
	 {
		 return "home";
	 }
}
