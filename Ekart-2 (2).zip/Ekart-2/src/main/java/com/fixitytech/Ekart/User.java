package com.fixitytech.Ekart;

public class User {
 String uname;
 String upassword;
 String uemail;
 String ucontact;
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getUpassword() {
	return upassword;
}
public void setUpassword(String upassword) {
	this.upassword = upassword;
}
public String getUemail() {
	return uemail;
}
public void setUemail(String uemail) {
	this.uemail = uemail;
}
public String getUcontact() {
	return ucontact;
}
public void setUcontact(String ucontact) {
	this.ucontact = ucontact;
}

}
