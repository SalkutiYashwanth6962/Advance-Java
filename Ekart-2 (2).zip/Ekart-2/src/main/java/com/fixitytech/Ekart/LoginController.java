package com.fixitytech.Ekart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LoginController {
	
	@Autowired
	UserDAO userdao;
	@RequestMapping(value="/login" ,method=RequestMethod.GET)
	public String login() {
	 return "login";
	 
  }
	@RequestMapping(value="/login",method=RequestMethod.POST)

	public String login1(String uname,String upassword) {
//		if(uname.equals(upassword)) {
//			return "redirect:home";
//		}
		if(userdao.validate(uname, upassword)) {
			return "home";
		}
		else {
			
			return "login";
		}
		 
		 
	  }
}
